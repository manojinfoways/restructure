
module.exports = {
    customer: require('./customer'),
    producer: require('./producer'),
    admin: require('./admin'),
    // products: require('./products'),
    shopping: require('./shopping'),
    agent: require('./agent')
}
